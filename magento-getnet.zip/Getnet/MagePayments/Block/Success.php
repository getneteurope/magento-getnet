<?php

namespace Getnet\MagePayments\Block;

use Magento\Framework\View\Element\Template;
use Magento\Checkout\Model\Session as CheckoutSession;

class Success extends Template
{
    protected $checkoutSession;

    public function __construct(
        Template\Context $context,
        CheckoutSession $checkoutSession,
        array $data = []
    ) {
        $this->checkoutSession = $checkoutSession;
        parent::__construct($context, $data);
    }

    public function getCustomData()
    {
        // Aquí puedes obtener los datos adicionales que deseas mostrar en la página de éxito
        $order = $this->checkoutSession->getLastRealOrder();
        
        $state = $order->getState();

        $payment = $order->getPayment();
        $amount = $order->getGrandTotal();
        $currency = $order->getOrderCurrencyCode();
        
        $reference   = $payment->getAdditionalInformation('reference_MB_ID');
        $entity      = $payment->getAdditionalInformation('PaymentEntityID');
        $paymentType = $payment->getAdditionalInformation('payment-methods');
        
        
        try{
            $expirationDate  = $payment->getAdditionalInformation('expirationDate');

            $expirationDate = "2023-07-23T15:45:51.408Z";  
            $date = str_replace('-"', '/', $expirationDate);  
            $newDate = date("Y/m/d H:i:s", strtotime($date));  
        } catch (\Exception $e) {
                    $expirationDate = ' ';
                    $this->logger->debug($e->getMessage());
        }
        
        if($paymentType == 'multibanco'){
            $result = '<h2>'.__("Datos Adicionales:").'</h2>
                       <p>'.__("Entity: ").$entity.'</p>
                       <p>'.__("Reference: ").$reference.'</p>
                       <p>'.__("Amount: ").$amount.' '.$currency.'</p>
                       <p>'.__("Expiration Date: ").$newDate.'</p>';
        } else {
            $result = '-';
        }
        
        // Ejemplo: obtener el número de orden
        return $result;
    }
    
}