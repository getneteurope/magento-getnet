<?php
/**
 * Plugin Name:       Magento GetNet
 * Plugin URI:        -
 * Description:       -
 * Author:            -
 * Author URI:        -
 * License:           Copyright © 2023 PagoNxt Merchant Solutions S.L. and Santander España Merchant Services, Entidad de Pago, S.L.U. 
 * You may not use this file except in compliance with the License which is available here https://opensource.org/licenses/AFL-3.0 
 * License URI:       https://opensource.org/licenses/AFL-3.0
 *
 */
namespace Getnet\MagePayments\Controller\Webhook;

use Magento\Sales\Model\Order\Email\Sender\OrderSender;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\HTTP\ClientFactory;


class Refund extends \Magento\Framework\App\Action\Action
{
    protected $messageManager;

    protected $logger;
        
    protected $resultPageFactory;

    protected $orderRepository;

    protected $curlFactory;
    
    private $remoteAddress;

    protected $orderSender;

    /**
     * @param \Magento\Framework\App\Action\Context       $context
     * @param \Magento\Framework\View\Result\PageFactory  $resultPageFactory
     * @param \Magento\Sales\Api\OrderRepositoryInterface $orderRepository
     */
    public function __construct(
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\HTTP\PhpEnvironment\RemoteAddress $remoteAddress,
		ClientFactory $curlFactory,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
        OrderSender $orderSender
        
    ) {

        $this->remoteAddress = $remoteAddress;
		$this->curlFactory = $curlFactory;
        $this->messageManager = $messageManager;
        $this->resultPageFactory = $resultPageFactory;
        $this->orderRepository = $orderRepository;
        $this->orderSender = $orderSender;
        $this->logger = $logger;
        parent::__construct($context);
    }
    /**
     * Detect Mobile view or Desktop View
     *
     * @return void
     */
    public function execute()
    {
        
        $orderId = $this->getRequest()->getParam('id');        

        $this->logger->debug('Entro Refund con id --> '.$orderId);
        $this->logger->debug('----------------------');
        
        $order = $this->orderRepository->get($orderId);
        $state = $order->getState();
        
        $this->logger->debug('Get status --> '.$state);
        
      //////////////////////////////////////////////////////
      //////// validate date for Cancel or Refund //////////
      //////////////////////////////////////////////////////
      $dateTrx = date_create($order->getCreatedAt());
      $dateTrx = date_format($dateTrx,"d/m/Y");
      $sysdate = date("d/m/Y");
      $this->logger->debug($dateTrx);

      
      $payment = $order->getPayment();
      $amount = $order->getGrandTotal();
      $currency = $order->getOrderCurrencyCode();

      $ip = $this->remoteAddress->getRemoteAddress();
        
        
        if($state == 'processing'){
            
             /////////////////   ADDITIONAL INFORMATION   //////////////////  
                try{
                    $requestID = $payment->getAdditionalInformation('requestID');
                    $parentTrx =  $payment->getAdditionalInformation('transaction-id');
                    $paymentMethod =  $payment->getAdditionalInformation('payment-methods');
                    $transactionType = $payment->getAdditionalInformation('transaction-type');
                    $merchantAccountID = $payment->getAdditionalInformation('merchantAccountID');
                    $magentoVersion = $payment->getAdditionalInformation('magVersion');
                    $maid = $payment->getAdditionalInformation('maid');
                    $iban = $payment->getAdditionalInformation('iban');
                    $bic =  $payment->getAdditionalInformation('bic');
                    $firstname = $payment->getAdditionalInformation('name');
                    $lastname = $payment->getAdditionalInformation('lastname');
                    $test = $payment->getAdditionalInformation('test');
                    $settings = $payment->getAdditionalInformation('settings');
                    $orderItems = $payment->getAdditionalInformation('orderItems');
            
                    $settings= base64_decode($settings);
                    $arrayBody = explode("&&&", $settings);
                    
                    $username = $arrayBody[0];
                    $password = $arrayBody[1];
                } catch (\Exception $e) {
                    $this->logger->debug('---error---'.$e.'-');
                }
        
        
                 ////////////////////////////////////////////////////////
                 //           1 --> Test Mode activated
                 if($test == '1'){ 
                           $url = 'https://api-test.getneteurope.com/engine/rest/payments/';
                           
                           if($paymentMethod == 'sofortbanking' || $paymentMethod == 'ideal' || $paymentMethod == 'sepadirectdebit'){
                              $url = 'https://api-test.getneteurope.com/engine/rest/paymentmethods/'; 
                           }
            
                 } else { //produccion
                           $url = 'https://api.getneteurope.com/engine/rest/payments/';
                           
                          if($paymentMethod == 'sofortbanking' || $paymentMethod == 'ideal' || $paymentMethod == 'sepadirectdebit'){
                              $url = 'https://api.getneteurope.com/engine/rest/paymentmethods/'; 
                           }
                 }
            
            
            
                $action = 'refund';
                
    
                //  table status
                $transactionType = $this->getTransactionRefund($action, $transactionType, $paymentMethod);  
        
                $newRequestID = time().'REFUND'.substr($requestID,10,20);
                $varAmount = '';
                $account = '';
                
                
                $this->logger->debug('Payment Method --> ' . $paymentMethod);
        
            if($paymentMethod == 'sofortbanking' || $paymentMethod == 'alipay-xborder' || $paymentMethod == 'ideal' || $paymentMethod == 'sepadirectdebit' || $paymentMethod == 'blik'){
               $varAmount = '"requested-amount": {
                                "value": '.$amount.',
                                "currency": "'.$currency.'"
                },'; 
            }

            if($paymentMethod == 'ideal'){
                $account = '"account-holder": {
                "first-name": "'.$firstname.'",
                "last-name": "'.$lastname.'"
                },
                "bank-account" : {
                  "bic" : "'.$bic.'",
                  "iban" : "'.$iban.'"
                },';
                
            } else if($paymentMethod == 'sepadirectdebit' || $paymentMethod == 'sofortbanking'){
                $account = '"account-holder": {
                "first-name": "'.$firstname.'",
                "last-name": "'.$lastname.'"
                },
                "bank-account" : {
                      "iban" : "'.$iban.'"
                    },';
                    
                    
            } else if($paymentMethod  == 'ratepay-invoice' || $paymentMethod  == 'ratepay-elv'){        
                $varAmount = '"requested-amount": {
                                "value": '.$amount.',
                                "currency": "'.$currency.'"
                    },'.$orderItems.',';
    
            }
            
             $shopVersion = '"shop":{
                    "system-name":"Magento",
                    "system-version":"'.$magentoVersion.'",
                    "plugin-name":"Magento_getnet_plugin",
                    "plugin-version":"1.1.2",
                    "integration-type":"redirect"
                },';    
            
    
        if($paymentMethod == 'ideal' || $paymentMethod == 'sepadirectdebit' ||  $paymentMethod == 'sofortbanking'){
             $xml = '{
                    "payment": {
                        "merchant-account-id": {
                            "value": "'.$maid.'"
                        },
                        "request-id": "'.$newRequestID.'",
                        "transaction-type": "'.$transactionType.'",
                        "payment-methods": {
                            "payment-method": [
                                {
                                    "name": "sepacredit"
                                }   
                            ]
                        },
                        '.$varAmount.'
                        '.$account.'
                        '.$shopVersion.'
                        "ip-address": "'.$ip.'",
                        "parent-transaction-id": "'.$parentTrx.'"
                    }
                }';
            
        } else {
             $xml = '{
                        "payment": {
                            "merchant-account-id": {
                                "value": "'.$merchantAccountID.'"
                            },
                            '.$varAmount.'
                            '.$shopVersion.'
                            "request-id": "'.$newRequestID.'",
                            "transaction-type": "'.$transactionType.'",
                            "ip-address": "'.$ip.'",
                            "parent-transaction-id": "'.$parentTrx.'"
                        }
                    }';
        }


                $this->logger->debug($xml);  
                $response = '';
                
                try {
                    $credentials = base64_encode( $username . ':' . $password);
                    
        			$httpHeaders = new \Zend\Http\Headers();
                    $httpHeaders->addHeaders([
                        'Accept' => 'application/json',
                        'Content-Type' => 'application/json',
                        'Authorization' => 'Basic ' .$credentials
                    ]);
                    $request = new \Zend\Http\Request();
                    $request->setHeaders($httpHeaders);
                    $request->setUri($url);
                    $request->setMethod(\Zend\Http\Request::METHOD_POST);
        
                    $request->setContent($xml);
        
                    $client = new \Zend\Http\Client();
                    $options = [
                        'adapter' => 'Zend\Http\Client\Adapter\Curl',
                        'curloptions' => [CURLOPT_FOLLOWLOCATION => true],
                        'maxredirects' => 1,
                        'timeout' => 30
                    ];
                    $client->setOptions($options);
                    $response = $client->send($request);
                    $response = $response->getBody();

                    $this->logger->debug($response);  
                } catch (\Magento\Framework\Exception\Exception $e) {
                     $this->logger->debug('Error Refund');
                }
            
        try{                
             //json to object
                $jsonResponse=json_decode($response , true);
                
                $newStatus = $jsonResponse["payment"]["transaction-state"];
                $newTransactionType = $jsonResponse["payment"]["transaction-type"];
                $newRequestID = $jsonResponse["payment"]["request-id"];
                $newMerchantAccountID = $jsonResponse["payment"]["merchant-account-id"]["value"];
                
                $success = '';
                $more = '';
                $message = ' --> ';
                $note = '';
                     
                 foreach ($jsonResponse['payment']['statuses']['status'] as $info) {
                    if (array_key_exists('code', $info) && array_key_exists('description', $info)) {
                            $message .= " {$info['code']}: {$info['description']}  ";
                            $note = "{$info['description']}  ";
                            
                    }
                }
                
                

                if (str_contains($newStatus, 'success') ) {

                        //start refund
                        $payment = $order->getPayment();
                        $payment->setAdditionalInformation('requestID', $newRequestID);
                        $payment->setAdditionalInformation('transaction-type', $newTransactionType);
                        $payment->setAdditionalInformation('merchantAccountID', $newMerchantAccountID);
                        $payment->save();
                                    
                        if($paymentMethod == 'sepadirectdebit'){
                            if($newTransactionType == 'debit' || $newTransactionType == 'credit'){
                                   $success = 'yes';
                                   $more = ' - ' . $newTransactionType;
                            } else {
                                   $success = 'no';
                            }
    
                        } else {
                           $success = 'yes';
                        }
                 
                } else if (str_contains($note , 'The Requested Amount exceeds')) {
                            $message = "The requested amount exceeds the initial transaction amount. This operation has already been completed.";
                            $note = "The requested amount exceeds the initial transaction amount. This operation has already been completed.";
                            $success = 'no';  

                } else {
                        $success = 'no';
                        $more = ' - ' . $newTransactionType;
                }
                
               if (str_contains($newRequestID, '-')) {
                  $arrayBody = explode("-", $newRequestID);
                  $newRequestID  = $arrayBody[0];
                }
                
                
                if($success == 'yes'){
                           $order->setState(\Magento\Sales\Model\Order::STATE_CANCELED);
                           $order->setStatus(\Magento\Sales\Model\Order::STATE_CANCELED);
                                $this->orderSender->send($order);
                           $order->addStatusToHistory('canceled',__('Refund of the order placed ') . $more . $message, false);
                           $order->save();
                           $this->messageManager->addSuccessMessage(__('Refund Success.'));

                } else {
                      if($paymentMethod == 'sepadirectdebit'){
                          $order->addStatusToHistory('processing',__('New transaction-type ->').$newTransactionType .', requestID: ' .$newRequestID .'  ,' . $message, false);
                      } else {
                          $order->addStatusToHistory('processing', $note, false);
                      }
                        
                        $order->save();
                            $this->messageManager->addErrorMessage( $note );
                }
                
            } catch (\Exception $e) {
                         $this->logger->debug('Error Refund');
            }  
                    
        
            
        } else {
                    $order->addStatusToHistory('processing',__('Invalid Status '), false);
                    $order->save();
                        $this->logger->debug('Status canceled');
                        $this->messageManager->addErrorMessage(__('Invalid Operation.'));
        }
        

        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        $resultRedirect->setUrl($this->_redirect->getRefererUrl());
        $this->logger->debug('--- End refund --');
                
        return $resultRedirect;
    }
    
    
    
    
    
  /**
   * 
   * 
   * 
   */
    private function getTransactionRefund($action, $transactionType, $paymentMethod)
    {
         $this->logger->debug('Transaction Type --> ' . $transactionType);
        
        if($paymentMethod  == 'creditcard'){
            if($transactionType == 'capture-authorization'){
                $newtransactionType= 'refund-capture';
                
            } else if($transactionType == 'purchase'){
                $newtransactionType= 'refund-purchase';
            }


        } else if($paymentMethod  == 'paypal'){
                if($transactionType == 'capture-authorization'){
                    $newtransactionType= 'refund-capture';
                    
                } else if($transactionType == 'debit'){
                    $newtransactionType= 'refund-debit';
                }
                        

        } else if($paymentMethod  == 'ideal'){
                        $newtransactionType= 'credit';
                        
        } else if($paymentMethod  == 'sepadirectdebit'){
                        $newtransactionType= 'credit';
                                    
        } else if($paymentMethod  == 'sofortbanking'){
                        $newtransactionType= 'credit';
        
        } else if($paymentMethod  == 'alipay-xborder'){ 
                        $newtransactionType= 'refund-debit';
        
        } else if($paymentMethod  == 'p24'){
                        $newtransactionType= 'refund-request';
        
        } else if($paymentMethod  == 'blik'){
                        $newtransactionType= 'refund-debit';
        
        } else if($paymentMethod  == 'bizum'){
                        $newtransactionType= 'refund-capture';

        } else if($paymentMethod  == 'ratepay-invoice'){
                        $newtransactionType= 'refund-capture';
                        
        } else if($paymentMethod  == 'ratepay-elv'){
                        $newtransactionType= 'refund-capture';
        
        } else if($paymentMethod  == 'mbway'){
                if($transactionType == 'capture-authorization'){
                    $newtransactionType= 'refund-capture';
                    
                } else if($transactionType == 'debit'){
                    $newtransactionType= 'refund-debit';
                }
                
        } else if($paymentMethod  == 'multibanco'){
                if($transactionType == 'capture-authorization'){
                    $newtransactionType= 'refund-capture';
                    
                } else if($transactionType == 'debit'){
                    $newtransactionType= 'refund-debit';
                }        
        
        } else {
                $newtransactionType= 'refund-capture';
        }
        
        $this->logger->debug('newtransaction Type --> ' . $newtransactionType);
        
        return $newtransactionType;    
    }
}