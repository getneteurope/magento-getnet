<?php
/**
 * Plugin Name:       Magento GetNet
 * Plugin URI:        -
 * Description:       -
 * Version:           1.0.8
 * Author:            -
 * Author URI:        -
 * License:           Copyright © 2023 PagoNxt Merchant Solutions S.L. and Santander España Merchant Services, Entidad de Pago, S.L.U. 
 * You may not use this file except in compliance with the License which is available here https://opensource.org/licenses/AFL-3.0 
 * License URI:       https://opensource.org/licenses/AFL-3.0
 *
 */
namespace Getnet\MagePayments\Model;

class Constants 
{
    private $_spIds = [
            'USER' => '515272-ShopPluginTest',
            'PASS' => 'SK6OWY5gdi6;',
            'SECRET' => '9acaf138-7ecb-4bc0-8f4f-b38efaec45df',
            'MERCHANT_ACCOUNT' => '515272-ResShopPlugin',
            'CREDITOR' => 'DE98ZZZ09999999999',
        ];


    public function getParams()
    {
        return [
            'test' => $this->getReturnUrl(),
            'params'        =>  $this->_spIds,
        ];
    }
    
    
}
