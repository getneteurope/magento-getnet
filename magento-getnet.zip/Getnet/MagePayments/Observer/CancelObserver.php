<?php
/**
 * Plugin Name:       Magento GetNet
 * Plugin URI:        -
 * Description:       -
 * Version:           1.0.8
 * Author:            -
 * Author URI:        -
 * License:           Copyright © 2023 PagoNxt Merchant Solutions S.L. and Santander España Merchant Services, Entidad de Pago, S.L.U. 
 * You may not use this file except in compliance with the License which is available here https://opensource.org/licenses/AFL-3.0 
 * License URI:       https://opensource.org/licenses/AFL-3.0
 *
 */
namespace Getnet\MagePayments\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;
use Magento\Sales\Model\Order;
use Magento\Framework\HTTP\ClientFactory;

class CancelObserver implements ObserverInterface
{
   protected $messageManager;

   protected $curlFactory;
    
   protected $order;
   
   private $remoteAddress;
   
   protected $logger;

    public function __construct(
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Magento\Framework\HTTP\PhpEnvironment\RemoteAddress $remoteAddress,
		ClientFactory $curlFactory,
        \Psr\Log\LoggerInterface $logger,
        Order $order
    )
    {
        $this->messageManager = $messageManager;
        $this->remoteAddress = $remoteAddress;
		$this->curlFactory = $curlFactory;
        $this->order = $order;
        $this->logger = $logger;
    }
    
    
    
   /**
   * Sets order status to pending
   * @param \Magento\Framework\Event\Observer $observer
   * @return void
   */
    public function execute(\Magento\Framework\Event\Observer $observer){
          $this->logger->debug('--------------------------------------------');
          $this->logger->debug('----Cancel observer');
      
          $order = $observer->getEvent()->getOrder();
    
          $state = $order->getState();
      
      
          //////////////////////////////////////////////////////
          //////// validate date for Cancel or Refund //////////
          //////////////////////////////////////////////////////
          $dateTrx = date_create($order->getCreatedAt());
          $dateTrx = date_format($dateTrx,"d/m/Y");
          $sysdate = date("d/m/Y");
          $this->logger->debug($dateTrx);
    
          
          $payment = $order->getPayment();
          $amount = $order->getGrandTotal();
          $currency = $order->getOrderCurrencyCode();

    
          $ip = $this->remoteAddress->getRemoteAddress();
    

         /////////////////   ADDITIONAL INFORMATION   //////////////////  
        try{
            $requestID = $payment->getAdditionalInformation('requestID');
            $parentTrx =  $payment->getAdditionalInformation('transaction-id');
            $paymentMethod =  $payment->getAdditionalInformation('payment-methods');
            $transactionType = $payment->getAdditionalInformation('transaction-type');
            $merchantAccountID = $payment->getAdditionalInformation('merchantAccountID');
            $magentoVersion = $payment->getAdditionalInformation('magVersion');
            $test = $payment->getAdditionalInformation('test');
            $settings = $payment->getAdditionalInformation('settings');
    
            $settings= base64_decode($settings);
            $arrayBody = explode("&&&", $settings);
            
            $username = $arrayBody[0];
            $password = $arrayBody[1];
        } catch (\Exception $e) {
            $this->logger->debug('---error---'.$e.'-');
        }

      
        $this->logger->debug('paymentMethod --> '.$paymentMethod);
        $this->logger->debug('transactionType --> '.$transactionType);
      
      if($transactionType == 'debit' ||  str_contains($transactionType, 'refund') || ($transactionType == 'authorization' && $paymentMethod == 'sepadirectdebit')){
          $this->logger->debug('Invalid Operation --> '.$transactionType);
          throw new \Magento\Framework\Exception\LocalizedException(__("Invalid Operation"));
          
      } else { 

         ////////////////////////////////////////////////////////
         //           1 --> Test Mode activated
         if($test == '1'){ 
                   $url = 'https://api-test.getneteurope.com/engine/rest/payments/';
                   
                   if($paymentMethod == 'sepadirectdebit'){
                      $url = 'https://api-test.getneteurope.com/engine/rest/paymentmethods/'; 
                   }
            
         } else { //produccion
                   $url = 'https://api.getneteurope.com/engine/rest/payments/';
                   
                  if($paymentMethod == 'sepadirectdebit'){
                      $url = 'https://api.getneteurope.com/engine/rest/paymentmethods/'; 
                   }
         }
         
         
         
           ///////////////////////////////////////////////////////////////
           //////      Debit transactions are not canceled      /////////
            if (str_contains($transactionType, 'debit') && ($paymentMethod  != 'sepadirectdebit') ) {
                
                     if($dateTrx == $sysdate){ //Same day but is debit, You can not cancel
                            throw new \Magento\Framework\Exception\LocalizedException(__("The payment was with a debit card, cancellation not allowed"));
        
                     } else { //Different day,  No cancel but you can make the return
                         $action = 'refund';
                     }
                 
            } else {
                    // Set the transaction type according to the action (void => cancel , refund => refund)
                      if($dateTrx == $sysdate){ 
                          $action = 'void';
            
                      } else { 
                          $action = 'refund';
                      }
            }
    
                  
                //  table status
                $transactionType = $this->getTransactionType($action, $transactionType, $paymentMethod);  
        
                $newRequestID = time().'POS'.substr($requestID,10,20);
                $varAmount = '';
                $account = '';
                
                
                $this->logger->debug('Payment Method --> ' . $paymentMethod);
        
                if($paymentMethod == 'alipay-xborder' || $paymentMethod == 'sepadirectdebit'){
                   $varAmount = '"requested-amount": {
                                    "value": '.$amount.',
                                    "currency": "'.$currency.'"
                    },'; 
                }
    
    
             $xml = '{
                        "payment": {
                            "merchant-account-id": {
                                "value": "'.$merchantAccountID.'"
                            },
                            "shop":{
                                "system-name":"Magento",
                                "system-version":"'.$magentoVersion.'",
                                "plugin-name":"Magento_getnet_plugin",
                                "plugin-version":"1.0.8",
                                "integration-type":"redirect"
                            },
                            '.$varAmount.'
                            "request-id": "'.$newRequestID.'",
                            "transaction-type": "'.$transactionType.'",
                            "ip-address": "'.$ip.'",
                            "parent-transaction-id": "'.$parentTrx.'"
                        }
                    }';
    
               
    
    
//                $this->logger->debug($xml);  
                $response = '';
                $message = '';
                $note = '';
                    
                $response = '';
                
                try {
                    $credentials = base64_encode( $username . ':' . $password);
                    
        			$httpHeaders = new \Zend\Http\Headers();
                    $httpHeaders->addHeaders([
                        'Accept' => 'application/json',
                        'Content-Type' => 'application/json',
                        'Authorization' => 'Basic ' .$credentials
                    ]);
                    $request = new \Zend\Http\Request();
                    $request->setHeaders($httpHeaders);
                    $request->setUri($url);
                    $request->setMethod(\Zend\Http\Request::METHOD_POST);
        
                    $request->setContent($xml);
        
                    $client = new \Zend\Http\Client();
                    $options = [
                        'adapter' => 'Zend\Http\Client\Adapter\Curl',
                        'curloptions' => [CURLOPT_FOLLOWLOCATION => true],
                        'maxredirects' => 1,
                        'timeout' => 30
                    ];
                    $client->setOptions($options);
                    $response = $client->send($request);
                    $response = $response->getBody();

//                    $this->logger->debug($response);  
                } catch (\Magento\Framework\Exception\Exception $e) {
                     $this->logger->debug('Error generate HPP');
                }
                
                 
                 $this->logger->debug('--');
                 $jsondata=json_decode($response , true);
                                      
                $this->logger->debug('-1-');                       
                 foreach ($jsondata['payment']['statuses']['status'] as $info) {
                    if (array_key_exists('code', $info) && array_key_exists('description', $info)) {
                            $message .= " {$info['code']}: {$info['description']}  ";
                            $note = "{$info['description']}  ";
                            
                    }
                }


        try {
            if (str_contains($response, '"transaction-state":"success"') ) {
    
                  if ($action == 'refund') {
                        $this->messageManager->addSuccessMessage(__('Refund of the order placed ') . $note);
                        $order->addStatusToHistory('canceled',__('Refund of the order placed ') . $message, false);
                   } else {
                       $order->addStatusToHistory('canceled',__('Cancel placed ') . $message, false);
                   }
                   
                $order->save();

            } else if (str_contains($response, '"transaction-state":"failed"') ) {
                        if (str_contains($response, 'The Requested Amount exceeds')) {
                            $message = "The requested amount exceeds the initial transaction amount. This operation has already been completed.";
                        }
                    $order->addStatusToHistory($state,  $message, false);
                    $order->save();
                    

            } else {

                throw new \Magento\Framework\Exception\LocalizedException(__("Fail to Cancel") . ' ,' . $note);
            }
         } catch (\Exception $e) {
                 $this->logger->debug(e);
                 $this->logger->debug('Error Cancel');
                 throw new \Magento\Framework\Exception\LocalizedException(__("Invalid Operation"));
         } 

      }


    $this->logger->debug('--fin--');
    }
    
  
  
  
  
  
  /**
   * 
   * 
   * 
   */
    private function getTransactionType($action, $transactionType, $paymentMethod)
    {
        
       if($paymentMethod  == 'creditcard'){
            if($action == 'void'){
                        if($transactionType == 'purchase'){
                            $NewtransactionType = 'void-purchase';
                            
                        } else if($transactionType == 'capture-authorization'){
                            $NewtransactionType = 'void-capture';

                        } else {
                            $NewtransactionType = 'void-authorization';
                        }
                        
            } else if($action == 'refund'){
                       if($transactionType == 'purchase'){
                            $NewtransactionType = 'refund-purchase';
                        } else {
                            $NewtransactionType = 'refund-capture';
                        }
            }
            
        } else if($paymentMethod  == 'paypal'){
            if($action == 'void'){
                        if($transactionType == 'authorization'){
                            $NewtransactionType = 'void-authorization';
                            
                        } else if($transactionType == 'capture-authorization'){
                            $NewtransactionType = 'void-capture';
                        }
                        
            } else if($action == 'refund'){
                        if($transactionType == 'debit'){
                            $NewtransactionType = 'refund-debit';
                        } else {
                            $NewtransactionType = 'refund-capture';
                        }
            }
            
        } else if($paymentMethod  == 'sepadirectdebit'){
            if($transactionType == 'pending-debit'){
                $NewtransactionType = 'void-pending-debit';
                
            } else if($transactionType == 'pending-credit'){
                $NewtransactionType = 'void-pending-credit';
            }
        
        } else if($paymentMethod  == 'alipay-xborder'){
                        $NewtransactionType = 'refund-debit';
        
        } else if($paymentMethod  == 'p24'){
                        $NewtransactionType = 'refund-request';
        
        } else if($paymentMethod  == 'blik'){ //review word
                        $NewtransactionType = 'refund-debit';
        }
        
        return $NewtransactionType;    
    }
    
    
}